module.exports = {
    DB_USER: "root",
    DB_PASS: "cdIldXYiTd1@",
    DB_HOST: "localhost",
    DB_NAME:"clinica"
};